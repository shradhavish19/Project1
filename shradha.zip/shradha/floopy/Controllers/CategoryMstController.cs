﻿using floopy.Common;
using floopy.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace floopy.Controllers
{
    public class CategoryMstController : Controller
    {
        ApplicationDbContext _db;
        public CategoryMstController()
        {
            _db = new ApplicationDbContext();
        }
        // GET: CategoryMst

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(CategoryMst cat)
        {
            if (cat.cat_id == 0)
            {
                _db.CategorieMsts.Add(cat);
                _db.SaveChanges();
            }
            else
            {
                var Updata = _db.CategorieMsts.FirstOrDefault(a => a.cat_id == cat.cat_id);
                Updata.cat_id = cat.cat_id;
                Updata.cat_name = cat.cat_name;
                _db.SaveChanges();
            }
            return RedirectToAction("CategoryList");                      
        }

        public ActionResult CategoryList()
        {
            var catList = _db.CategorieMsts.ToList();
            return View(catList);
        }

        public ActionResult Edit(int id)
        {
            var catType = _db.CategorieMsts.FirstOrDefault(a=> a.cat_id==id);
            return View("Create", catType);
        }

        public ActionResult Delete(int id)
        {
            var DelData = _db.CategorieMsts.FirstOrDefault(a => a.cat_id == id);
            _db.CategorieMsts.Remove(DelData);
            _db.SaveChanges();
            return RedirectToAction("CategoryList");
        }

    }
}