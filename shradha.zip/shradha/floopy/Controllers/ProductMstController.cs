﻿using floopy.Common;
using floopy.DTO;
using floopy.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace floopy.Controllers
{
    public class ProductMstController : Controller
    {
        ApplicationDbContext _db = new ApplicationDbContext();
        // GET: ProductMst
        [HttpGet]
        public ActionResult AddUpadteForm()
        {
            var pageLoadData = new ProductMstDTO
            {
                CategoryMstList = _db.CategorieMsts.ToList()
            };

            return View(pageLoadData);
        }

        public ActionResult ProductList()
        {
            var ProductList = from a in _db.ProductMsts
                              join b in _db.CategorieMsts on a.fk_pro_id equals b.cat_id
                              select new ProductListDTO
                              {
                                  pro_id = a.pro_id,
                                  pro_name = a.pro_name,
                                  fk_pro_id = a.fk_pro_id,
                                  cat_name = b.cat_name
                              };
            return View(ProductList);
        }

        public ActionResult Edit(int id)
        {
            var EditData = new ProductMstDTO
            {
                productMst = _db.ProductMsts.FirstOrDefault(a => a.pro_id == id),
                CategoryMstList = _db.CategorieMsts.ToList()
            };
            return View("AddUpadteForm", EditData);
        }

        public ActionResult Delete(int id)
        {
           var DelData = _db.ProductMsts.FirstOrDefault(a => a.pro_id == id);
            _db.ProductMsts.Remove(DelData);
            _db.SaveChanges();
            return RedirectToAction("ProductList");
        }

        [HttpPost]
        public ActionResult AddUpadteForm(ProductMstDTO product)
        {
            if (product.productMst.pro_id == 0)
            {
                _db.ProductMsts.Add(product.productMst);
                _db.SaveChanges();
            }
            else
            {
                var UpdateData = _db.ProductMsts.FirstOrDefault(a => a.pro_id == product.productMst.pro_id);
                UpdateData.pro_id = product.productMst.pro_id;
                UpdateData.fk_pro_id = product.productMst.fk_pro_id;
                UpdateData.pro_name = product.productMst.pro_name;
                UpdateData.pro_price = product.productMst.pro_price;
                _db.SaveChanges();
            }
            return RedirectToAction("ProductList");
        }
    }
}