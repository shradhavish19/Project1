﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace floopy.DTO
{
    public class ProductListDTO
    {
        [Display(Name = "Product ID")]
        public int pro_id { get; set; }
        [Display(Name = "Product Name")]
        public string pro_name { get; set; }
        [Display(Name = "Category ID")]
        public int fk_pro_id { get; set; }
        [Display(Name = "Category Name")]
        public string cat_name { get; set; }
    }
}