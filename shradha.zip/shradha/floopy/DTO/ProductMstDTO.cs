﻿using floopy.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace floopy.DTO
{
    public class ProductMstDTO
    {
        public List<CategoryMst> CategoryMstList { get; set; }
        [Display(Name="Product Master")]
        public ProductMst productMst { get; set; }
    }
}