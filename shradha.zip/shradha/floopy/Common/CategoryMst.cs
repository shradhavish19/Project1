﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace floopy.Common
{
    public class CategoryMst
    {
        [Key]
       public int cat_id { get; set; }
        public string cat_name { get; set; }
    }
   
}