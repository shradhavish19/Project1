﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace floopy.Common
{

    public class ProductMst
    {
        [Key]
        public int pro_id { get; set; }
        public int fk_pro_id { get; set; }
        public string pro_name { get; set; }
        public double pro_price { get; set; }
    }
}